# VictorianOS v0.01 — AOSP + Runnable Shell Foundation

Working title only. This repository is the first practical foundation for a modern Android-derived OS with a restrained neo-Victorian instrument aesthetic.

## What this is

This is **not yet a flashable ROM**. It contains two deliberately separate layers:

1. `shell/` — an installable Android launcher/shell prototype that establishes the real interaction language now.
2. `aosp/vendor/victorianos/` — an AOSP vendor/product/overlay scaffold intended to become the actual ROM layer once device-specific sources for the target phone are available and validated.

The target discussed for initial hardware bring-up is Realme C51 / RMX3830 (`hulk`, Unisoc T612). Do not flash anything from this repo as a ROM image; there is no boot/vendor/device tree included yet.

## v0.01 features

- Custom HOME/launcher activity
- Instrument-style home screen drawn natively (no webview)
- Command/search console
- App discovery and launch
- Battery percentage + charging state
- Charging sequence shown as a restrained regulator animation
- System settings shortcuts
- Victorian-modern color/typography tokens
- AOSP product makefile scaffold
- Runtime resource overlays for SystemUI and Settings
- Boot animation asset pipeline
- RMX3830 bring-up checklist

## Design law

> Nothing appears unless it communicates something or lets the user do something.

This OS is meant to feel like a precision instrument, not a steampunk theme pack and definitely not an anime “SYSTEM” overlay.

## Build the shell prototype

Open `shell/` in Android Studio and run it on Android 8.0+.

After installation, press Home and choose **VictorianOS Shell** as the launcher.

The prototype can demonstrate charging behavior while the launcher is visible. Android does not allow an ordinary third-party app to replace the real lock-screen/SystemUI charging path; that part belongs to the AOSP integration layer.

## AOSP path

The actual ROM path is:

- obtain/validate device tree, kernel source/config, vendor blobs and partition map
- bring up a minimal AOSP-derived build for RMX3830
- add the custom shell as the default HOME app
- add resource overlays for SystemUI + Settings
- integrate charging animation at SystemUI/Keyguard level
- replace boot animation, sounds and wallpapers
- progressively replace more stock surfaces only after telephony, camera, audio, Wi-Fi, Bluetooth, sensors and power management are stable

See `docs/ARCHITECTURE.md` and `docs/RMX3830_BRINGUP.md`.

## Current scope warning

Bootloader unlocking, partition flashing and vendor bring-up can erase data or brick a device. The repository intentionally contains no one-click flashing script in v0.01.
