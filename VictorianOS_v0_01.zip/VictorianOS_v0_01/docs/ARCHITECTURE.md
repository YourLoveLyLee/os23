# Architecture

## Layer 1 — Shell (works on stock Android)

Package: `com.lee.victorianos.shell`

Responsibilities:

- HOME launcher
- command/app search
- visual identity and motion system
- app launching
- user-facing battery/charging instrumentation
- future widget host
- future notification listener companion

This layer lets the UX mature before risking ROM flashing.

## Layer 2 — Privileged system apps (AOSP build)

Once included in a ROM image, the shell can receive privileged capabilities that ordinary apps cannot safely provide. Candidate modules:

- `VictorianShell` — default HOME
- `VictorianPowerUI` — SystemUI charging surface
- `VictorianControls` — quick settings and device controls
- `VictorianSetup` — first boot experience

Do not create separate apps when a small SystemUI extension is enough.

## Layer 3 — Runtime Resource Overlays

Use RRO packages to restyle stock SystemUI/Settings resources where behavior does not need replacement.

This is safer than forking huge platform apps too early.

## Layer 4 — Framework/SystemUI changes

Only fork platform code for interactions that cannot be achieved cleanly with overlays, such as:

- lock-screen charging choreography
- custom quick-settings layout behavior
- power menu structure
- ambient display instrumentation
- system-wide transition choreography

## Hardware boundary

The OS UI can be mostly device-independent. Hardware bring-up is not.

A flashable RMX3830 build eventually needs:

- bootloader access
- partition map and AVB strategy
- device tree
- kernel source or compatible prebuilt strategy
- vendor blobs
- sepolicy
- init configuration
- audio/camera/sensor/telephony HAL compatibility
- verified recovery path before daily use
