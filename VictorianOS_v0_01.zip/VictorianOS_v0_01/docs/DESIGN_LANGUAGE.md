# VictorianOS Design Language

## Intent

A smartphone from a world where Victorian-era precision craft evolved directly into modern electronics.

It should feel engineered, calm and expensive. Avoid costume-steampunk clichés.

## Materials translated into pixels

- Enamel Black — primary background
- Smoked Glass — translucent panels
- Gunmetal — secondary surfaces
- Aged Brass — active/high-value accents only
- Ivory — primary text
- Silver — dividers, inactive instrumentation
- Amber — power/charging emphasis
- Cyan — connectivity/measurement emphasis
- Crimson — warnings only

## Geometry

- Fine 1–2 px rules rather than fat card borders
- Slightly clipped corners on larger panels
- Circular dials only when the data is genuinely radial/progressive
- Long engraved-label shapes for commands and metadata
- Avoid gratuitous gears; any mechanical motif must indicate state or transition

## Motion

Animations should imply mechanisms:

- align
- latch
- regulate
- settle
- retract

Recommended timings:

- tactile response: 80–140 ms
- panel transition: 180–260 ms
- ceremonial/system transition: 500–900 ms
- charging entrance: 1.8–2.8 s, then quiet ambient state

No endless decorative motion on the home screen.

## Typography

Use a highly readable modern sans-serif for data and controls. Victorian character should come from layout, spacing, rules and occasional display lettering—not unreadable faux-antique fonts.

## Language

Use normal, concise system copy:

- Power connected
- Charging rapidly
- Battery temperature normal
- Wi-Fi unavailable
- 34 min remaining

Avoid faux-sentient or roleplay copy:

- SYSTEM AWAKENED
- WELCOME, MASTER
- CORE SYNCHRONIZATION COMPLETE

## Charging interaction

1. Cable/current detected.
2. A fine line rises from the bottom edge.
3. Regulator ring resolves around the percentage.
4. Incoming power and thermal state appear briefly.
5. Needle/ring settles.
6. Peripheral detail retracts, leaving a quiet charge indicator.
7. Unplugging reverses the current line and dismisses the instrument.
