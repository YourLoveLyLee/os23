# RMX3830 Bring-up Notes

Target: Realme C51, model RMX3830. Community device lists commonly use codename `hulk`. The SoC is Unisoc T612.

## Do not flash v0.01

This repository does not contain a complete device tree, kernel, vendor image set, vbmeta strategy or tested recovery image.

## Before ROM work

Record from the device:

- exact firmware build number
- Android version
- region/export variant
- `adb shell getprop` output
- partition names/sizes
- current slot state if A/B is used
- boot/vendor_boot/init_boot presence
- AVB/vbmeta state
- stock boot/recovery images

Keep a complete stock firmware package and a verified recovery procedure on a PC before changing partitions.

## Bring-up order

1. Bootloader and recovery path verified.
2. Boot minimal system image.
3. ADB stable.
4. Display/touch.
5. Storage and encryption.
6. Wi-Fi + Bluetooth.
7. Audio.
8. Sensors.
9. RIL/SIM/data/SMS/calls.
10. Camera.
11. Charging/power/thermal behavior.
12. Fingerprint/biometrics if applicable.
13. Only then make it a daily-use OS.

## UI integration order

1. VictorianShell as HOME.
2. Boot animation.
3. RRO colors/dimens.
4. SystemUI charging surface.
5. Quick settings.
6. Lockscreen/AOD.
7. Power menu and volume UI.
8. Setup Wizard and Settings identity.
