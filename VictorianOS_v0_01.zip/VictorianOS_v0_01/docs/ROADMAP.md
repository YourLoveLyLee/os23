# Roadmap

## v0.01 — Instrument foundation
- launcher
- command search
- battery instrument
- charging entrance
- AOSP/RRO skeleton

## v0.02 — Daily shell
- app drawer/search ranking
- notification listener panel
- widget host
- wallpaper/scene engine
- haptic language
- sound pack hooks
- theme settings

## v0.03 — System surfaces
- lockscreen concept in AOSP tree
- quick settings layout
- volume panel
- power menu
- charging/thermal status

## v0.04 — Device bring-up branch
- RMX3830 device-specific tree
- vendor extraction scripts
- kernel integration
- SELinux policy
- recovery/rollback documentation

## v0.05 — Daily-driver candidate
- telephony/camera/audio/power validation
- OTA/update strategy
- crash telemetry kept local by default
- backup/export tools
