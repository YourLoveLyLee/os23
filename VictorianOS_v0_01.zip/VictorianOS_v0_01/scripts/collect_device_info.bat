@echo off
set OUT=rmx3830-device-info.txt
(
  echo VictorianOS RMX3830 read-only device inventory
  echo.
  echo === adb devices ===
  adb devices -l
  echo.
  echo === getprop ===
  adb shell getprop
  echo.
  echo === partitions ===
  adb shell "ls -l /dev/block/by-name 2>/dev/null || true"
  echo.
  echo === battery ===
  adb shell dumpsys battery
  echo.
  echo === display ===
  adb shell wm size
  adb shell wm density
) > %OUT%
echo Wrote %OUT%
