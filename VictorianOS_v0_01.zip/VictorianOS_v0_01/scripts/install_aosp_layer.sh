#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 /path/to/aosp-root"
  exit 1
fi
SRC="$(cd "$(dirname "$0")/../aosp/vendor/victorianos" && pwd)"
DST="$1/vendor/victorianos"
mkdir -p "$DST"
cp -a "$SRC/." "$DST/"
echo "Installed VictorianOS vendor layer to $DST"
echo "Next: source build/envsetup.sh && lunch victorian_hulk-userdebug"
echo "Note: RMX3830 device-specific sources are still required before this can produce a bootable device image."
