from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import math, shutil, subprocess, os

root = Path(__file__).resolve().parents[1]
out = root / 'aosp' / 'bootanimation'
frames = out / 'part0'
if frames.exists():
    shutil.rmtree(frames)
frames.mkdir(parents=True)

W, H, FPS, N = 720, 1600, 30, 54
BG = (11,12,13)
IVORY = (232,225,210)
SILVER = (135,140,145)
BRASS = (169,134,75)
DIM = (48,50,52)

try:
    font_big = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf', 46)
    font_small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 18)
except Exception:
    font_big = ImageFont.load_default()
    font_small = ImageFont.load_default()

for i in range(N):
    t = i/(N-1)
    im = Image.new('RGB', (W,H), BG)
    d = ImageDraw.Draw(im)
    cx, cy = W//2, H//2 - 70
    r = 146

    # restrained frame marks
    d.line((70, 120, 150, 120), fill=DIM, width=2)
    d.line((W-150, 120, W-70, 120), fill=DIM, width=2)
    d.line((70, H-120, 150, H-120), fill=DIM, width=2)
    d.line((W-150, H-120, W-70, H-120), fill=DIM, width=2)

    # current line rises first
    rise = max(0, min(1, t/0.28))
    y0 = H-100
    y1 = int(y0 - (y0-(cy+r+28))*(1-(1-rise)**3))
    d.line((cx,y0,cx,y1), fill=BRASS, width=3)

    # regulator arc appears
    rp = max(0, min(1, (t-0.12)/0.48))
    bbox = (cx-r, cy-r, cx+r, cy+r)
    d.ellipse(bbox, outline=DIM, width=2)
    if rp > 0:
        d.arc(bbox, start=-90, end=-90 + 360*(1-(1-rp)**3), fill=BRASS, width=4)

    # ticks
    alpha_phase = max(0, min(1, (t-0.25)/0.25))
    tick_col = tuple(int(DIM[j] + (SILVER[j]-DIM[j])*alpha_phase) for j in range(3))
    for k in range(24):
        a = math.radians(-90 + k*15)
        rr1 = r-15 if k%6==0 else r-9
        x1 = cx + math.cos(a)*rr1
        y1t = cy + math.sin(a)*rr1
        x2 = cx + math.cos(a)*r
        y2t = cy + math.sin(a)*r
        d.line((x1,y1t,x2,y2t), fill=tick_col, width=2)

    # center pin + needle settles to 72% as a neutral boot motif
    settle = max(0, min(1, (t-0.42)/0.32))
    angle = math.radians(-150 + 300*0.72*(1-(1-settle)**3))
    nr = r-38
    nx, ny = cx + math.cos(angle)*nr, cy + math.sin(angle)*nr
    d.line((cx,cy,nx,ny), fill=BRASS, width=3)
    d.ellipse((cx-5,cy-5,cx+5,cy+5), fill=IVORY)

    # name only appears after mechanism has resolved
    if t > 0.50:
        fade = max(0, min(1, (t-0.50)/0.28))
        txt = 'VICTORIANOS'
        box = d.textbbox((0,0), txt, font=font_big)
        tw = box[2]-box[0]
        col = tuple(int(BG[j] + (IVORY[j]-BG[j])*fade) for j in range(3))
        d.text((cx-tw/2, cy+r+92), txt, fill=col, font=font_big)
        sub = 'INSTRUMENT SYSTEM'
        box2 = d.textbbox((0,0), sub, font=font_small)
        sw = box2[2]-box2[0]
        scol = tuple(int(BG[j] + (SILVER[j]-BG[j])*fade) for j in range(3))
        d.text((cx-sw/2, cy+r+160), sub, fill=scol, font=font_small)

    # final hold is calm; no looped ornament
    im.save(frames / f'{i:05d}.png', optimize=True)

(out / 'desc.txt').write_text(f'{W} {H} {FPS}\np 1 20 part0\n', encoding='utf-8')
print(f'Generated {N} frames in {frames}')
