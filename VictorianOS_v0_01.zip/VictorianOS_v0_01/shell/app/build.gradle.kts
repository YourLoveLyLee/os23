plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lee.victorianos.shell"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lee.victorianos.shell"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.01"
    }

    buildFeatures {
        buildConfig = true
    }
}
