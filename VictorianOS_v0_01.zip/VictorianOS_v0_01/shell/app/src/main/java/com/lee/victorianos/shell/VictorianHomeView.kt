package com.lee.victorianos.shell

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class VictorianHomeView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(value: Float) = value * density

    private val enamel = Color.rgb(11, 12, 13)
    private val gunmetal = Color.rgb(23, 26, 29)
    private val ivory = Color.rgb(232, 225, 210)
    private val silver = Color.rgb(167, 173, 178)
    private val brass = Color.rgb(169, 134, 75)
    private val amber = Color.rgb(211, 154, 69)
    private val cyan = Color.rgb(119, 174, 182)
    private val dim = Color.rgb(80, 84, 87)

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ivory
        typeface = Typeface.create("sans", Typeface.NORMAL)
    }
    private val displayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ivory
        typeface = Typeface.create("serif", Typeface.NORMAL)
    }

    var onCommandRequested: (() -> Unit)? = null
    var onAppRequested: ((AppEntry) -> Unit)? = null

    val apps: List<AppEntry> by lazy { loadApps() }
    private val appHitRects = mutableListOf<Pair<RectF, AppEntry>>()
    private val commandRect = RectF()

    private var batteryPercent = 0
    private var batteryTemperatureC = 0f
    private var batteryVoltageV = 0f
    private var estimatedPowerW: Float? = null
    private var powerConnected = false
    private var chargeCeremonyStartedAt = 0L
    private var ceremonial = false

    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("EEE, d MMM", Locale.getDefault())

    init {
        setBackgroundColor(enamel)
        isFocusable = true
        postInvalidateOnAnimation()
    }

    fun refreshBatteryFrom(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        batteryPercent = ((level.toFloat() / scale.toFloat()) * 100f).toInt().coerceIn(0, 100)
        batteryTemperatureC = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        batteryVoltageV = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        powerConnected = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val manager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val microAmps = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        estimatedPowerW = if (microAmps != Int.MIN_VALUE && batteryVoltageV > 0f) {
            abs(microAmps.toFloat()) / 1_000_000f * batteryVoltageV
        } else null
        invalidate()
    }

    fun setPowerConnected(connected: Boolean, ceremonial: Boolean) {
        powerConnected = connected
        this.ceremonial = connected && ceremonial
        if (this.ceremonial) chargeCeremonyStartedAt = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBackgroundStructure(canvas)
        drawHeader(canvas)
        drawCentralInstrument(canvas)
        drawCommandPlate(canvas)
        drawAppDock(canvas)
        if (powerConnected) drawAmbientChargeMark(canvas)
        if (ceremonial) drawChargeCeremony(canvas)

        // Clock and the charge ceremony are alive, but the rest of the shell stays still.
        postInvalidateDelayed(if (ceremonial) 16L else 1000L)
    }

    private fun drawBackgroundStructure(canvas: Canvas) {
        val margin = dp(18f)
        linePaint.color = Color.rgb(42, 44, 46)
        linePaint.strokeWidth = dp(1f)
        canvas.drawLine(margin, dp(54f), width - margin, dp(54f), linePaint)
        canvas.drawLine(margin, height - dp(116f), width - margin, height - dp(116f), linePaint)

        // Small corner calibration marks: useful visual rhythm, not decorative filigree.
        linePaint.color = brass
        val l = dp(12f)
        canvas.drawLine(margin, dp(76f), margin + l, dp(76f), linePaint)
        canvas.drawLine(margin, dp(76f), margin, dp(76f) + l, linePaint)
        canvas.drawLine(width - margin, dp(76f), width - margin - l, dp(76f), linePaint)
        canvas.drawLine(width - margin, dp(76f), width - margin, dp(76f) + l, linePaint)
    }

    private fun drawHeader(canvas: Canvas) {
        val now = Date()
        textPaint.color = silver
        textPaint.textSize = dp(10f)
        textPaint.letterSpacing = 0.14f
        canvas.drawText(dateFormat.format(now).uppercase(Locale.getDefault()), dp(22f), dp(34f), textPaint)

        textPaint.letterSpacing = 0f
        textPaint.textAlign = Paint.Align.RIGHT
        val state = if (powerConnected) "${batteryPercent}% · POWER" else "${batteryPercent}%"
        canvas.drawText(state, width - dp(22f), dp(34f), textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawCentralInstrument(canvas: Canvas) {
        val cx = width / 2f
        val cy = height * 0.31f
        val radius = min(width, height) * 0.17f

        linePaint.strokeWidth = dp(1f)
        linePaint.color = dim
        canvas.drawCircle(cx, cy, radius, linePaint)
        linePaint.color = brass
        canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), -90f, 360f * (batteryPercent/100f), false, linePaint)

        // Tick marks work as a real percentage scale.
        for (i in 0 until 24) {
            val angle = Math.toRadians((-90.0 + i * 15.0))
            val r1 = radius - dp(if (i % 6 == 0) 9f else 5f)
            val x1 = cx + cos(angle).toFloat() * r1
            val y1 = cy + sin(angle).toFloat() * r1
            val x2 = cx + cos(angle).toFloat() * radius
            val y2 = cy + sin(angle).toFloat() * radius
            linePaint.color = if (i % 6 == 0) silver else dim
            canvas.drawLine(x1, y1, x2, y2, linePaint)
        }

        displayPaint.textAlign = Paint.Align.CENTER
        displayPaint.color = ivory
        displayPaint.textSize = dp(46f)
        canvas.drawText(clockFormat.format(Date()), cx, cy + dp(9f), displayPaint)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = silver
        textPaint.textSize = dp(9f)
        textPaint.letterSpacing = 0.2f
        canvas.drawText("LOCAL TIME", cx, cy + dp(34f), textPaint)
        textPaint.letterSpacing = 0f
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawCommandPlate(canvas: Canvas) {
        val left = dp(28f)
        val right = width - dp(28f)
        val top = height * 0.52f
        val bottom = top + dp(54f)
        commandRect.set(left, top, right, bottom)

        fillPaint.color = gunmetal
        canvas.drawRoundRect(commandRect, dp(3f), dp(3f), fillPaint)
        linePaint.color = Color.rgb(58, 60, 62)
        canvas.drawRoundRect(commandRect, dp(3f), dp(3f), linePaint)
        linePaint.color = brass
        canvas.drawLine(left + dp(14f), bottom - dp(8f), left + dp(54f), bottom - dp(8f), linePaint)

        textPaint.color = ivory
        textPaint.textSize = dp(14f)
        canvas.drawText("Command / Search", left + dp(16f), top + dp(23f), textPaint)
        textPaint.color = silver
        textPaint.textSize = dp(10f)
        canvas.drawText("apps · settings · instruments", left + dp(16f), top + dp(40f), textPaint)
    }

    private fun drawAppDock(canvas: Canvas) {
        appHitRects.clear()
        val visibleApps = apps.filterNot { it.packageName == context.packageName }.take(8)
        if (visibleApps.isEmpty()) return

        val columns = 4
        val startY = height * 0.66f
        val cellW = width / columns.toFloat()
        val iconSize = dp(42f)

        visibleApps.forEachIndexed { index, app ->
            val col = index % columns
            val row = index / columns
            val cx = cellW * col + cellW / 2f
            val cy = startY + row * dp(84f)
            val rect = RectF(cx - dp(34f), cy - dp(34f), cx + dp(34f), cy + dp(45f))
            appHitRects += rect to app

            linePaint.color = Color.rgb(54, 57, 60)
            canvas.drawCircle(cx, cy, dp(25f), linePaint)
            linePaint.color = if (row == 0) brass else dim
            canvas.drawArc(RectF(cx-dp(29f), cy-dp(29f), cx+dp(29f), cy+dp(29f)), 210f, 120f, false, linePaint)

            app.icon?.let { drawable ->
                val half = (iconSize / 2f).toInt()
                drawable.setBounds((cx-half).toInt(), (cy-half).toInt(), (cx+half).toInt(), (cy+half).toInt())
                drawable.draw(canvas)
            }

            textPaint.textAlign = Paint.Align.CENTER
            textPaint.color = silver
            textPaint.textSize = dp(9f)
            canvas.drawText(app.label.take(14), cx, cy + dp(42f), textPaint)
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawAmbientChargeMark(canvas: Canvas) {
        val baseline = height - dp(58f)
        val left = dp(26f)
        linePaint.color = amber
        linePaint.strokeWidth = dp(1.5f)
        canvas.drawLine(left, baseline, left + dp(30f), baseline, linePaint)

        textPaint.color = silver
        textPaint.textSize = dp(9f)
        val watts = estimatedPowerW?.let { String.format(Locale.US, "%.1f W", it) } ?: "current measured"
        canvas.drawText("CHARGING · $watts · ${String.format(Locale.US, "%.1f°C", batteryTemperatureC)}", left + dp(38f), baseline + dp(3f), textPaint)
    }

    private fun drawChargeCeremony(canvas: Canvas) {
        val elapsed = (SystemClock.uptimeMillis() - chargeCeremonyStartedAt).coerceAtLeast(0L)
        val p = (elapsed / 2400f).coerceIn(0f, 1f)
        if (p >= 1f) {
            ceremonial = false
            return
        }

        // Dark glass veil.
        fillPaint.color = Color.argb((205 * smoothStep(p.coerceAtMost(0.35f) / 0.35f)).toInt(), 5, 6, 7)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fillPaint)

        val cx = width / 2f
        val cy = height * 0.46f
        val radius = dp(88f)

        // Current rises from the physical cable edge.
        val rise = ((p / 0.34f).coerceIn(0f, 1f))
        linePaint.color = amber
        linePaint.strokeWidth = dp(1.4f)
        canvas.drawLine(cx, height.toFloat(), cx, height - (height - cy - radius) * easeOutCubic(rise), linePaint)

        // The regulator resolves after contact.
        val ringP = ((p - 0.18f) / 0.46f).coerceIn(0f, 1f)
        linePaint.color = brass
        linePaint.strokeWidth = dp(1.5f)
        canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), -90f, 360f * easeOutCubic(ringP), false, linePaint)

        val inner = radius - dp(12f)
        linePaint.color = Color.rgb(65, 65, 62)
        canvas.drawCircle(cx, cy, inner, linePaint)

        val settle = ((p - 0.48f) / 0.34f).coerceIn(0f, 1f)
        val needleAngle = Math.toRadians((-150.0 + 300.0 * (batteryPercent / 100.0) * easeOutCubic(settle)))
        val nx = cx + cos(needleAngle).toFloat() * (inner - dp(18f))
        val ny = cy + sin(needleAngle).toFloat() * (inner - dp(18f))
        linePaint.color = amber
        canvas.drawLine(cx, cy, nx, ny, linePaint)
        fillPaint.color = ivory
        canvas.drawCircle(cx, cy, dp(2.5f), fillPaint)

        displayPaint.textAlign = Paint.Align.CENTER
        displayPaint.color = ivory
        displayPaint.textSize = dp(42f)
        canvas.drawText("$batteryPercent%", cx, cy + dp(12f), displayPaint)

        val infoP = ((p - 0.52f) / 0.22f).coerceIn(0f, 1f)
        textPaint.alpha = (255 * infoP).toInt()
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = silver
        textPaint.textSize = dp(10f)
        textPaint.letterSpacing = 0.12f
        canvas.drawText("POWER CONNECTED", cx, cy + radius + dp(34f), textPaint)
        textPaint.letterSpacing = 0f
        textPaint.textSize = dp(9f)
        val details = buildString {
            estimatedPowerW?.let { append(String.format(Locale.US, "%.1f W  ·  ", it)) }
            append(String.format(Locale.US, "%.1f°C", batteryTemperatureC))
        }
        canvas.drawText(details, cx, cy + radius + dp(54f), textPaint)
        textPaint.alpha = 255
        textPaint.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        if (ceremonial) {
            ceremonial = false
            invalidate()
            return true
        }

        if (commandRect.contains(event.x, event.y)) {
            onCommandRequested?.invoke()
            return true
        }

        appHitRects.firstOrNull { it.first.contains(event.x, event.y) }?.second?.let {
            onAppRequested?.invoke(it)
            return true
        }
        return true
    }

    private fun loadApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

        return infos.mapNotNull { info ->
            val activity = info.activityInfo ?: return@mapNotNull null
            AppEntry(
                label = info.loadLabel(pm).toString(),
                packageName = activity.packageName,
                component = android.content.ComponentName(activity.packageName, activity.name),
                icon = runCatching { info.loadIcon(pm) }.getOrNull()
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    private fun smoothStep(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun easeOutCubic(x: Float): Float {
        val t = x.coerceIn(0f, 1f)
        val inv = 1f - t
        return 1f - inv * inv * inv
    }
}
