package com.lee.victorianos.shell

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var homeView: VictorianHomeView
    private var powerReceiverRegistered = false

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!::homeView.isInitialized) return

            when (intent?.action) {
                Intent.ACTION_POWER_CONNECTED -> homeView.setPowerConnected(true, ceremonial = true)
                Intent.ACTION_POWER_DISCONNECTED -> homeView.setPowerConnected(false, ceremonial = false)
                Intent.ACTION_BATTERY_CHANGED -> homeView.refreshBatteryFrom(intent)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        configureWindowSafely()

        homeView = VictorianHomeView(this).apply {
            onCommandRequested = { showCommandConsole() }
            onAppRequested = { launchApp(it) }
        }
        setContentView(homeView)

        registerPowerReceiverSafely()
    }

    override fun onDestroy() {
        if (powerReceiverRegistered) {
            runCatching { unregisterReceiver(powerReceiver) }
            powerReceiverRegistered = false
        }
        super.onDestroy()
    }

    private fun configureWindowSafely() {
        runCatching {
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    controller.hide(WindowInsets.Type.statusBars())
                    controller.systemBarsBehavior =
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
        }
    }

    private fun registerPowerReceiverSafely() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }

        val stickyBattery = runCatching {
            val sticky = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                // These are protected system broadcasts. Explicitly mark the runtime
                // receiver exported so Android 13+ / OEM receiver rules cannot reject it.
                registerReceiver(powerReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(powerReceiver, filter)
            }
            powerReceiverRegistered = true
            sticky
        }.getOrElse {
            powerReceiverRegistered = false
            // The launcher should still work even if an OEM refuses receiver registration.
            runCatching {
                @Suppress("DEPRECATION")
                registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            }.getOrNull()
        }

        stickyBattery?.let { homeView.refreshBatteryFrom(it) }
    }

    private fun showCommandConsole() {
        val field = EditText(this).apply {
            hint = "Search apps or enter a command"
            setSingleLine(true)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Command Console")
            .setView(field)
            .setNegativeButton("Dismiss", null)
            .setPositiveButton("Run", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val command = field.text.toString().trim()
                if (command.isNotEmpty() && executeCommand(command)) dialog.dismiss()
            }
            field.requestFocus()
            dialog.window?.setSoftInputMode(
                android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
            )
        }
        dialog.show()
    }

    private fun executeCommand(raw: String): Boolean {
        val command = raw.lowercase().trim()
        val action = when (command) {
            "wifi", "wi-fi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth", "bt" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "battery", "power" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "settings", "config" -> Intent(Settings.ACTION_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound", "audio" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            else -> null
        }

        if (action != null) {
            runCatching { startActivity(action) }
                .onFailure {
                    Toast.makeText(this, "That system panel is unavailable.", Toast.LENGTH_SHORT).show()
                }
            return true
        }

        val match = homeView.apps
            .sortedBy { it.label.length }
            .firstOrNull {
                it.label.lowercase().contains(command) || it.packageName.lowercase().contains(command)
            }

        if (match != null) {
            launchApp(match)
            return true
        }

        Toast.makeText(this, "No instrument or app matched ‘$raw’.", Toast.LENGTH_SHORT).show()
        return false
    }

    private fun launchApp(app: AppEntry) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).apply {
                component = app.component
                addCategory(Intent.CATEGORY_LAUNCHER)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open ${app.label}.", Toast.LENGTH_SHORT).show()
        }
    }
}
