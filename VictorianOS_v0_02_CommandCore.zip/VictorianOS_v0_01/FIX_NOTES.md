# VictorianOS v0.01.1 startup-crash patch

This patch is aimed specifically at the crash that occurs immediately after Android selects VictorianOS Shell as HOME.

Changes:

- Replaced the unsafe `BatteryManager` cast with nullable, guarded battery telemetry.
- Made battery current/power telemetry optional so OEM-specific behavior cannot crash HOME.
- Made dynamic power/battery receiver registration defensive on Android 13+ and safe to unregister.
- Reused the sticky battery result from the receiver registration instead of doing a second unguarded query.
- Added a safe rendering fallback so one malformed app icon or draw exception cannot kill the launcher process.
- Hardened installed-app discovery and icon/label loading against broken third-party resources.
- Added a normal LAUNCHER entry as well as HOME so VictorianOS can be opened from the app drawer for testing before setting it as the default home app.
- Moved soft-keyboard window configuration until after the dialog exists.
- Bumped the prototype version to 0.01.1 / versionCode 2.

Recommended test order:

1. Uninstall the previous VictorianOS Shell if Android reports a signature/package conflict.
2. Install the new debug APK.
3. Open VictorianOS Shell from the app drawer first. It should render without taking over HOME.
4. Only after that works, set VictorianOS Shell as the default Home app.
5. Test unplugged, then connect a charger and verify battery instrumentation.

If it still terminates immediately, capture the Android crash stack trace (`FATAL EXCEPTION: main`) from logcat. At that point the stack trace will identify the exact OEM/runtime failure instead of guessing.
