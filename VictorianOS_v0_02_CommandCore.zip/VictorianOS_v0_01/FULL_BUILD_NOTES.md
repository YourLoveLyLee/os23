VictorianOS Shell v0.02.0 — Command Core

New in this build:
- Premium multi-panel launcher home screen
- Core Dial clock with live battery ring and charge pulse
- Full Application Registry (all apps drawer)
- Live search + category filters
- Favorites dock
- Suggested/continue cards
- Command console for app launches and system panels
- Swipe up to open registry
- Swipe down to open instruments panel

Workflow compatibility:
- The internal project folder is still VictorianOS_v0_01/shell
- You can replace the ZIP used by the current GitHub Actions workflow
