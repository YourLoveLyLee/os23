plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lee.victorianos.shell"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lee.victorianos.shell"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.02.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
