package com.lee.victorianos.shell

enum class AppCategory(val displayName: String) {
    ALL("All"),
    COMMUNICATION("Communication"),
    MEDIA("Media"),
    TOOLS("Tools"),
    GAMES("Games"),
    SYSTEM("System"),
    WEB("Web")
}
