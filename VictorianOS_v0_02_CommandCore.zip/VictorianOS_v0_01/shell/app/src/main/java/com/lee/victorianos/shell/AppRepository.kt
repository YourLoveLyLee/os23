package com.lee.victorianos.shell

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

class AppRepository(private val context: Context) {
    private val preferredPackages = listOf(
        "com.openai.chatgpt",
        "com.android.camera",
        "com.google.android.googlequicksearchbox",
        "com.android.settings",
        "com.android.chrome",
        "com.google.android.youtube",
        "com.android.calendar",
        "com.google.android.apps.photos",
        "com.facebook.katana",
        "com.roblox.client"
    )

    fun loadApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager

        val infos = runCatching {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, 0)
            }
        }.getOrElse { emptyList() }

        return infos.mapNotNull { info ->
            runCatching {
                val activity = info.activityInfo ?: return@runCatching null
                val label = runCatching { info.loadLabel(pm).toString() }
                    .getOrElse { activity.packageName.substringAfterLast('.') }
                val packageName = activity.packageName
                AppEntry(
                    label = label,
                    packageName = packageName,
                    component = ComponentName(packageName, activity.name),
                    icon = runCatching { info.loadIcon(pm) }.getOrNull(),
                    category = classify(label, packageName)
                )
            }.getOrNull()
        }
            .distinctBy { it.packageName }
            .filterNot { it.packageName == context.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun favoriteApps(apps: List<AppEntry>, maxCount: Int = 6): List<AppEntry> {
        val byPackage = apps.associateBy { it.packageName }
        val favorites = preferredPackages.mapNotNull { byPackage[it] }.toMutableList()

        val curated = apps.filter { it.category in listOf(AppCategory.COMMUNICATION, AppCategory.WEB, AppCategory.TOOLS, AppCategory.MEDIA) }
        for (app in curated) {
            if (favorites.none { it.packageName == app.packageName }) favorites += app
            if (favorites.size >= maxCount) break
        }

        if (favorites.size < maxCount) {
            for (app in apps) {
                if (favorites.none { it.packageName == app.packageName }) favorites += app
                if (favorites.size >= maxCount) break
            }
        }
        return favorites.take(maxCount)
    }

    fun suggestedApps(apps: List<AppEntry>, favorites: List<AppEntry>, maxCount: Int = 4): List<AppEntry> {
        val priority = listOf(AppCategory.TOOLS, AppCategory.SYSTEM, AppCategory.MEDIA, AppCategory.GAMES)
        return apps
            .filter { candidate -> favorites.none { it.packageName == candidate.packageName } }
            .sortedWith(compareBy<AppEntry>({ priority.indexOf(it.category).takeIf { idx -> idx >= 0 } ?: Int.MAX_VALUE }, { it.label.lowercase() }))
            .take(maxCount)
    }

    private fun classify(label: String, packageName: String): AppCategory {
        val text = (label + " " + packageName).lowercase()
        return when {
            listOf("chat", "message", "messenger", "discord", "mail", "facebook", "whatsapp", "telegram", "phone", "contact").any { it in text } -> AppCategory.COMMUNICATION
            listOf("camera", "photo", "gallery", "music", "video", "player", "youtube", "netflix", "spotify").any { it in text } -> AppCategory.MEDIA
            listOf("game", "roblox", "bitlife", "genshin", "star rail", "zzz").any { it in text } -> AppCategory.GAMES
            listOf("chrome", "browser", "search", "assistant", "opera", "edge").any { it in text } -> AppCategory.WEB
            listOf("setting", "manager", "tool", "calculator", "file", "clock", "calendar", "drive", "store", "market", "notes", "terminal").any { it in text } -> AppCategory.TOOLS
            packageName.startsWith("com.android") || packageName.startsWith("android") || listOf("system", "launcher", "security", "package installer").any { it in text } -> AppCategory.SYSTEM
            else -> AppCategory.ALL
        }
    }
}
