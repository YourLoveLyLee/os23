package com.lee.victorianos.shell

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.SystemClock
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class CoreDialView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(value: Float) = value * density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = VictorianPalette.ivory
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val displayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = VictorianPalette.ivory
        typeface = Typeface.create("serif", Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }

    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val secondsFormat = SimpleDateFormat("ss", Locale.getDefault())

    private var batteryPercent = 0
    private var batteryTemperatureC = 0f
    private var batteryVoltageV = 0f
    private var estimatedPowerW: Float? = null
    private var powerConnected = false
    private var chargeCeremonyStartedAt = 0L
    private var ceremonial = false

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun refreshBattery(level: Int, scale: Int, tempTenths: Int, voltageMilli: Int, status: Int, currentMicroAmps: Int?) {
        val safeScale = scale.coerceAtLeast(1)
        batteryPercent = ((level.toFloat() / safeScale.toFloat()) * 100f).toInt().coerceIn(0, 100)
        batteryTemperatureC = tempTenths / 10f
        batteryVoltageV = voltageMilli / 1000f
        powerConnected = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        estimatedPowerW = currentMicroAmps?.takeIf { it != Int.MIN_VALUE && batteryVoltageV > 0f }
            ?.let { abs(it.toFloat()) / 1_000_000f * batteryVoltageV }
        invalidate()
    }

    fun setPowerConnected(connected: Boolean, ceremonial: Boolean) {
        powerConnected = connected
        this.ceremonial = connected && ceremonial
        if (this.ceremonial) chargeCeremonyStartedAt = SystemClock.uptimeMillis()
        invalidate()
    }

    fun getStatusLine(): String {
        val watts = estimatedPowerW?.let { String.format(Locale.US, "%.1f W", it) } ?: "telemetry standby"
        return if (powerConnected) {
            "CHARGING · $watts · ${String.format(Locale.US, "%.1f°C", batteryTemperatureC)}"
        } else {
            "STANDBY · ${batteryPercent}% · ${String.format(Locale.US, "%.1f°C", batteryTemperatureC)}"
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f - dp(2f)
        val radius = min(width, height) * 0.38f
        val frame = RectF(cx - radius, cy - radius, cx + radius, cy + radius)

        fillPaint.color = VictorianPalette.panel
        canvas.drawCircle(cx, cy, radius + dp(18f), fillPaint)

        // Outer halo
        linePaint.color = VictorianPalette.cyanSoft
        linePaint.strokeWidth = dp(18f)
        canvas.drawArc(frame.insetCopy(dp(10f)), -90f, 360f, false, linePaint)

        // Primary frame
        linePaint.color = VictorianPalette.softLine
        linePaint.strokeWidth = dp(2f)
        canvas.drawCircle(cx, cy, radius, linePaint)

        // Brass battery arc
        linePaint.color = VictorianPalette.brass
        linePaint.strokeWidth = dp(3f)
        canvas.drawArc(frame, -90f, 360f * (batteryPercent / 100f), false, linePaint)

        // Seconds sweep for that more alive HUD feel.
        val seconds = secondsFormat.format(Date()).toIntOrNull() ?: 0
        linePaint.color = VictorianPalette.cyan
        linePaint.strokeWidth = dp(2f)
        canvas.drawArc(frame.insetCopy(dp(12f)), -90f, 6f * seconds, false, linePaint)

        for (i in 0 until 48) {
            val angle = Math.toRadians((-90.0 + i * 7.5))
            val outer = radius
            val inner = radius - dp(if (i % 6 == 0) 13f else 7f)
            val x1 = cx + cos(angle).toFloat() * inner
            val y1 = cy + sin(angle).toFloat() * inner
            val x2 = cx + cos(angle).toFloat() * outer
            val y2 = cy + sin(angle).toFloat() * outer
            linePaint.strokeWidth = dp(if (i % 6 == 0) 1.3f else 0.8f)
            linePaint.color = if (i % 6 == 0) VictorianPalette.silver else VictorianPalette.muted
            canvas.drawLine(x1, y1, x2, y2, linePaint)
        }

        displayPaint.color = VictorianPalette.ivory
        displayPaint.textSize = dp(54f)
        canvas.drawText(clockFormat.format(Date()), cx, cy + dp(12f), displayPaint)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = VictorianPalette.silver
        textPaint.textSize = dp(10f)
        textPaint.letterSpacing = 0.18f
        canvas.drawText("SYSTEM CORE", cx, cy + dp(40f), textPaint)

        textPaint.textSize = dp(9f)
        textPaint.letterSpacing = 0.10f
        canvas.drawText("BATTERY $batteryPercent%  ·  ${String.format(Locale.US, "%.1f°C", batteryTemperatureC)}", cx, cy - radius - dp(12f), textPaint)
        textPaint.letterSpacing = 0f
        textPaint.textAlign = Paint.Align.LEFT

        if (powerConnected) drawChargeAccent(canvas, cx, cy, radius)
        if (ceremonial) drawCeremony(canvas, cx, cy, radius)

        postInvalidateDelayed(if (ceremonial) 16L else 1000L)
    }

    private fun drawChargeAccent(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        linePaint.color = VictorianPalette.amber
        linePaint.strokeWidth = dp(2f)
        val accent = RectF(cx - radius - dp(8f), cy - radius - dp(8f), cx + radius + dp(8f), cy + radius + dp(8f))
        canvas.drawArc(accent, 205f, 54f, false, linePaint)
        canvas.drawArc(accent, 330f, 42f, false, linePaint)
    }

    private fun drawCeremony(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val elapsed = (SystemClock.uptimeMillis() - chargeCeremonyStartedAt).coerceAtLeast(0L)
        val p = (elapsed / 2200f).coerceIn(0f, 1f)
        if (p >= 1f) {
            ceremonial = false
            return
        }
        linePaint.color = VictorianPalette.amber
        linePaint.strokeWidth = dp(1.2f)
        val pulse = radius + dp(18f) + dp(20f) * p
        linePaint.alpha = ((1f - p) * 180).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, pulse, linePaint)
        linePaint.alpha = 255
    }

    private fun RectF.insetCopy(inset: Float): RectF = RectF(left + inset, top + inset, right - inset, bottom - inset)
}
