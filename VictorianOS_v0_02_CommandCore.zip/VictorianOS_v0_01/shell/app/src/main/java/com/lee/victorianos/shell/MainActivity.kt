package com.lee.victorianos.shell

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val appRepository by lazy { AppRepository(this) }
    private val allApps: List<AppEntry> by lazy { appRepository.loadApps() }
    private val favoriteApps: List<AppEntry> by lazy { appRepository.favoriteApps(allApps) }
    private val suggestedApps: List<AppEntry> by lazy { appRepository.suggestedApps(allApps, favoriteApps) }

    private lateinit var root: FrameLayout
    private lateinit var headerDate: TextView
    private lateinit var headerBattery: TextView
    private lateinit var statusStrip: TextView
    private lateinit var coreDial: CoreDialView
    private lateinit var favoritesContainer: LinearLayout
    private lateinit var suggestedContainer: LinearLayout

    private lateinit var drawerOverlay: FrameLayout
    private lateinit var drawerPanel: LinearLayout
    private lateinit var drawerSearch: EditText
    private lateinit var drawerGrid: GridLayout
    private lateinit var categoryRow: LinearLayout
    private lateinit var drawerSubtitle: TextView

    private var selectedCategory: AppCategory = AppCategory.ALL
    private var powerReceiverRegistered = false
    private var latestBatteryIntent: Intent? = null

    private val dateFormat = SimpleDateFormat("EEE, d MMM", Locale.getDefault())
    private val gestureDetector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                val start = e1 ?: return false
                val dy = e2.y - start.y
                if (kotlin.math.abs(dy) < dp(64f) || kotlin.math.abs(velocityY) < 800f) return false
                if (dy < 0) {
                    openDrawer()
                } else {
                    showQuickTools()
                }
                return true
            }
        })
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            latestBatteryIntent = intent
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    coreDial.setPowerConnected(true, ceremonial = true)
                    refreshBatteryUi(intent)
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    coreDial.setPowerConnected(false, ceremonial = false)
                    refreshBatteryUi(intent)
                }
                Intent.ACTION_BATTERY_CHANGED -> refreshBatteryUi(intent)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureWindowSafely()
        buildUi()
        registerPowerReceiverSafely()
        populateHomeSections()
        refreshHeader()
    }

    override fun onResume() {
        super.onResume()
        refreshHeader()
        latestBatteryIntent?.let { refreshBatteryUi(it) }
    }

    override fun onDestroy() {
        if (powerReceiverRegistered) {
            runCatching { unregisterReceiver(powerReceiver) }
            powerReceiverRegistered = false
        }
        super.onDestroy()
    }

    private fun buildUi() {
        root = object : FrameLayout(this) {
            override fun onTouchEvent(event: MotionEvent): Boolean {
                gestureDetector.onTouchEvent(event)
                return super.onTouchEvent(event)
            }
        }.apply {
            setBackgroundColor(VictorianPalette.enamel)
        }

        root.addView(VictorianBackdropView(this), FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpInt(20f), dpInt(18f), dpInt(20f), dpInt(18f))
            gravity = Gravity.TOP
        }

        content.addView(buildHeader())
        content.addView(space(dpInt(8f)))

        coreDial = CoreDialView(this)
        content.addView(coreDial, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dpInt(308f)
        ))

        content.addView(space(dpInt(6f)))
        content.addView(buildCommandBar())
        content.addView(space(dpInt(18f)))
        content.addView(sectionTitle("Primary Dock", "Tap to launch · Swipe up for all apps"))

        favoritesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        content.addView(space(dpInt(10f)))
        content.addView(favoritesContainer)

        content.addView(space(dpInt(20f)))
        content.addView(sectionTitle("Continue / Suggested", "System-curated access panel"))
        content.addView(space(dpInt(10f)))

        suggestedContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(suggestedContainer)

        content.addView(space(dpInt(16f)))
        statusStrip = TextView(this).apply {
            setTextColor(VictorianPalette.silver)
            textSize = 11f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dpInt(8f), dpInt(10f), dpInt(8f), dpInt(6f))
        }
        content.addView(statusStrip)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnTouchListener { _, event ->
                gestureDetector.onTouchEvent(event)
                false
            }
            addView(content, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        root.addView(scroll)

        buildDrawerOverlay()
        root.addView(drawerOverlay)

        setContentView(root)
    }

    private fun buildHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        headerDate = TextView(this).apply {
            setTextColor(VictorianPalette.ivory)
            textSize = 20f
            typeface = Typeface.create("serif", Typeface.NORMAL)
        }
        val caption = TextView(this).apply {
            text = "VictorianOS Shell · Command Core"
            setTextColor(VictorianPalette.silver)
            textSize = 10f
            letterSpacing = 0.12f
        }
        left.addView(headerDate)
        left.addView(caption)
        header.addView(left)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        headerBattery = infoCapsule("--% · STANDBY")
        actions.addView(headerBattery)
        actions.addView(space(dpInt(8f), horizontal = true))
        actions.addView(textButton("INSTRUMENTS") { showQuickTools() })
        actions.addView(space(dpInt(8f), horizontal = true))
        actions.addView(textButton("REGISTRY") { openDrawer() })
        header.addView(actions)
        return header
    }

    private fun buildCommandBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1f, radiusDp = 18f)
            setPadding(dpInt(18f), dpInt(14f), dpInt(18f), dpInt(14f))
            setOnClickListener { showCommandConsole() }
        }

        val title = TextView(this).apply {
            text = "Command / Search"
            setTextColor(VictorianPalette.ivory)
            textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val subtitle = TextView(this).apply {
            text = "Open apps, settings, or search the registry"
            setTextColor(VictorianPalette.silver)
            textSize = 12f
        }
        val accent = View(this).apply {
            setBackgroundColor(VictorianPalette.brass)
        }
        bar.addView(title)
        bar.addView(space(dpInt(4f)))
        bar.addView(subtitle)
        bar.addView(space(dpInt(10f)))
        bar.addView(accent, LinearLayout.LayoutParams(dpInt(72f), dpInt(2f)))
        return bar
    }

    private fun buildDrawerOverlay() {
        drawerOverlay = FrameLayout(this).apply {
            setBackgroundColor(0xD8080A0D.toInt())
            visibility = View.GONE
            alpha = 0f
            setOnClickListener { closeDrawer() }
        }

        drawerPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedPanel(VictorianPalette.panel, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1.2f, radiusDp = 24f)
            setPadding(dpInt(18f), dpInt(18f), dpInt(18f), dpInt(18f))
            isClickable = true
        }
        drawerPanel.setOnClickListener { /* consume */ }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val title = TextView(this).apply {
            text = "Application Registry"
            setTextColor(VictorianPalette.ivory)
            textSize = 20f
            typeface = Typeface.create("serif", Typeface.NORMAL)
        }
        drawerSubtitle = TextView(this).apply {
            setTextColor(VictorianPalette.silver)
            textSize = 11f
            text = "Search installed applications"
        }
        titleWrap.addView(title)
        titleWrap.addView(drawerSubtitle)
        titleRow.addView(titleWrap)
        titleRow.addView(textButton("CLOSE") { closeDrawer() })
        drawerPanel.addView(titleRow)
        drawerPanel.addView(space(dpInt(14f)))

        drawerSearch = EditText(this).apply {
            hint = "Type an app, package, or command"
            setHintTextColor(VictorianPalette.muted)
            setTextColor(VictorianPalette.ivory)
            background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1f, radiusDp = 16f)
            setPadding(dpInt(16f), dpInt(12f), dpInt(16f), dpInt(12f))
            inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    applyDrawerFilter()
                }
            })
        }
        drawerPanel.addView(drawerSearch)
        drawerPanel.addView(space(dpInt(12f)))

        val chipScroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipScroller.addView(categoryRow)
        drawerPanel.addView(chipScroller)
        drawerPanel.addView(space(dpInt(14f)))

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        drawerGrid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        scroll.addView(drawerGrid)
        drawerPanel.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))

        drawerOverlay.addView(drawerPanel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            Gravity.CENTER
        ).apply {
            setMargins(dpInt(14f), dpInt(58f), dpInt(14f), dpInt(20f))
        })
    }

    private fun populateHomeSections() {
        populateFavorites()
        populateSuggested()
        buildCategoryChips()
        applyDrawerFilter()
    }

    private fun populateFavorites() {
        favoritesContainer.removeAllViews()
        favoriteApps.forEachIndexed { index, app ->
            if (index > 0) favoritesContainer.addView(space(dpInt(10f), horizontal = true))
            favoritesContainer.addView(createHomeAppTile(app))
        }
    }

    private fun populateSuggested() {
        suggestedContainer.removeAllViews()
        val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val secondRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        suggestedApps.forEachIndexed { index, app ->
            val card = createSuggestionCard(app)
            val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (index % 2 == 0) {
                if (firstRow.childCount > 0) firstRow.addView(space(dpInt(10f), horizontal = true))
                firstRow.addView(card, params)
            } else {
                if (secondRow.childCount > 0) secondRow.addView(space(dpInt(10f), horizontal = true))
                secondRow.addView(card, params)
            }
        }
        if (firstRow.childCount > 0) suggestedContainer.addView(firstRow)
        if (secondRow.childCount > 0) {
            suggestedContainer.addView(space(dpInt(10f)))
            suggestedContainer.addView(secondRow)
        }
    }

    private fun createHomeAppTile(app: AppEntry): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setOnClickListener { launchApp(app) }
        }
        val iconShell = FrameLayout(this).apply {
            background = ringDrawable()
            setPadding(dpInt(14f), dpInt(14f), dpInt(14f), dpInt(14f))
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        iconShell.addView(icon, FrameLayout.LayoutParams(dpInt(38f), dpInt(38f), Gravity.CENTER))
        val label = TextView(this).apply {
            text = app.label.take(14)
            setTextColor(VictorianPalette.silver)
            textSize = 11f
            gravity = Gravity.CENTER
            maxLines = 1
        }
        tile.addView(iconShell, LinearLayout.LayoutParams(dpInt(74f), dpInt(74f)))
        tile.addView(space(dpInt(8f)))
        tile.addView(label)
        return tile
    }

    private fun createSuggestionCard(app: AppEntry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1f, radiusDp = 18f)
            setPadding(dpInt(12f), dpInt(12f), dpInt(12f), dpInt(12f))
            setOnClickListener { launchApp(app) }
        }
        val iconWrap = FrameLayout(this).apply {
            background = roundedPanel(VictorianPalette.enamel, strokeColor = VictorianPalette.line, strokeWidthDp = 1f, radiusDp = 14f)
            setPadding(dpInt(10f), dpInt(10f), dpInt(10f), dpInt(10f))
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        iconWrap.addView(icon, FrameLayout.LayoutParams(dpInt(28f), dpInt(28f), Gravity.CENTER))
        card.addView(iconWrap)
        card.addView(space(dpInt(10f), horizontal = true))
        val textWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textWrap.addView(TextView(this).apply {
            text = app.label
            setTextColor(VictorianPalette.ivory)
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        })
        textWrap.addView(TextView(this).apply {
            text = app.category.displayName.uppercase(Locale.getDefault())
            setTextColor(VictorianPalette.silver)
            textSize = 10f
            letterSpacing = 0.08f
        })
        card.addView(textWrap, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return card
    }

    private fun openDrawer(initialQuery: String = "") {
        drawerOverlay.visibility = View.VISIBLE
        drawerOverlay.animate().alpha(1f).setDuration(180L).start()
        drawerPanel.translationY = dp(32f)
        drawerPanel.animate().translationY(0f).setDuration(220L).start()
        if (drawerSearch.text.toString() != initialQuery) drawerSearch.setText(initialQuery)
        drawerSearch.setSelection(drawerSearch.text.length)
        drawerSearch.requestFocus()
        selectedCategory = AppCategory.ALL
        buildCategoryChips()
        applyDrawerFilter()
        showKeyboard(drawerSearch)
    }

    private fun closeDrawer() {
        hideKeyboard(drawerSearch)
        drawerOverlay.animate().alpha(0f).setDuration(160L).withEndAction {
            drawerOverlay.visibility = View.GONE
        }.start()
    }

    private fun buildCategoryChips() {
        categoryRow.removeAllViews()
        AppCategory.values().forEachIndexed { index, category ->
            if (index > 0) categoryRow.addView(space(dpInt(8f), horizontal = true))
            val chip = TextView(this).apply {
                text = category.displayName
                setPadding(dpInt(14f), dpInt(8f), dpInt(14f), dpInt(8f))
                textSize = 12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                val selected = selectedCategory == category
                setTextColor(if (selected) VictorianPalette.ivory else VictorianPalette.silver)
                background = roundedPanel(
                    if (selected) VictorianPalette.cyanSoft else VictorianPalette.panelElevated,
                    strokeColor = if (selected) VictorianPalette.cyan else VictorianPalette.softLine,
                    strokeWidthDp = 1f,
                    radiusDp = 999f
                )
                setOnClickListener {
                    selectedCategory = category
                    buildCategoryChips()
                    applyDrawerFilter()
                }
            }
            categoryRow.addView(chip)
        }
    }

    private fun applyDrawerFilter() {
        val query = drawerSearch.text.toString().trim().lowercase()
        val filtered = allApps.filter { app ->
            val categoryPass = selectedCategory == AppCategory.ALL || app.category == selectedCategory
            val queryPass = query.isBlank() || app.label.lowercase().contains(query) || app.packageName.lowercase().contains(query)
            categoryPass && queryPass
        }
        drawerSubtitle.text = when {
            query.isNotBlank() -> "${filtered.size} matches for \"$query\""
            selectedCategory != AppCategory.ALL -> "${filtered.size} apps in ${selectedCategory.displayName}"
            else -> "${allApps.size} installed applications"
        }
        populateDrawerGrid(filtered)
    }

    private fun populateDrawerGrid(apps: List<AppEntry>) {
        drawerGrid.removeAllViews()
        apps.forEach { app ->
            drawerGrid.addView(createDrawerAppTile(app), GridLayout.LayoutParams().apply {
                width = (resources.displayMetrics.widthPixels - dpInt(68f)) / 4
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                setMargins(dpInt(4f), dpInt(4f), dpInt(4f), dpInt(10f))
            })
        }
    }

    private fun createDrawerAppTile(app: AppEntry): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.line, strokeWidthDp = 1f, radiusDp = 16f)
            setPadding(dpInt(8f), dpInt(12f), dpInt(8f), dpInt(12f))
            setOnClickListener { launchApp(app) }
        }
        val iconWrap = FrameLayout(this).apply {
            background = ringDrawable()
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        iconWrap.addView(icon, FrameLayout.LayoutParams(dpInt(32f), dpInt(32f), Gravity.CENTER))
        tile.addView(iconWrap, LinearLayout.LayoutParams(dpInt(64f), dpInt(64f)))
        tile.addView(space(dpInt(8f)))
        tile.addView(TextView(this).apply {
            text = app.label.take(14)
            gravity = Gravity.CENTER
            setTextColor(VictorianPalette.ivory)
            textSize = 11f
            maxLines = 2
            minLines = 2
        })
        return tile
    }

    private fun launchApp(app: AppEntry) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).apply {
                component = app.component
                addCategory(Intent.CATEGORY_LAUNCHER)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            closeDrawer()
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open ${app.label}.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCommandConsole() {
        val field = EditText(this).apply {
            hint = "Try: settings, camera, open chatgpt, search calendar"
            setSingleLine(true)
            setTextColor(VictorianPalette.ivory)
            setHintTextColor(VictorianPalette.muted)
            inputType = InputType.TYPE_CLASS_TEXT
            background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1f, radiusDp = 14f)
            setPadding(dpInt(14f), dpInt(12f), dpInt(14f), dpInt(12f))
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpInt(6f), dpInt(10f), dpInt(6f), 0)
            addView(field)
            addView(space(dpInt(10f)))
            addView(TextView(this@MainActivity).apply {
                text = "Commands can open settings panels, launch apps, or search the registry."
                setTextColor(VictorianPalette.silver)
                textSize = 12f
            })
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Command Console")
            .setView(wrap)
            .setNegativeButton("Dismiss", null)
            .setPositiveButton("Run", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val command = field.text.toString().trim()
                if (command.isNotEmpty() && executeCommand(command)) dialog.dismiss()
            }
            field.requestFocus()
            dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }
        dialog.show()
    }

    private fun executeCommand(raw: String): Boolean {
        val command = raw.lowercase(Locale.getDefault()).trim()
        val normalized = command.removePrefix("open ").removePrefix("launch ")

        val settingsIntent = when (normalized) {
            "wifi", "wi-fi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth", "bt" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "battery", "power" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "settings", "system settings", "config" -> Intent(Settings.ACTION_SETTINGS)
            "display", "screen" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound", "audio" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "apps", "application settings" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
            else -> null
        }

        if (settingsIntent != null) {
            runCatching { startActivity(settingsIntent) }
                .onFailure { Toast.makeText(this, "That panel is unavailable.", Toast.LENGTH_SHORT).show() }
            return true
        }

        if (command.startsWith("search ")) {
            openDrawer(command.removePrefix("search ").trim())
            return true
        }

        val match = allApps
            .sortedBy { it.label.length }
            .firstOrNull {
                it.label.lowercase().contains(normalized) || it.packageName.lowercase().contains(normalized)
            }
        if (match != null) {
            launchApp(match)
            return true
        }

        openDrawer(normalized)
        Toast.makeText(this, "No direct match. Opened registry search instead.", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun showQuickTools() {
        val actions = listOf(
            "Wi-Fi" to Intent(Settings.ACTION_WIFI_SETTINGS),
            "Bluetooth" to Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
            "Display" to Intent(Settings.ACTION_DISPLAY_SETTINGS),
            "Sound" to Intent(Settings.ACTION_SOUND_SETTINGS),
            "Battery" to Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            "Settings" to Intent(Settings.ACTION_SETTINGS)
        )
        val labels = actions.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Instruments")
            .setItems(labels) { _, which ->
                runCatching { startActivity(actions[which].second) }
                    .onFailure { Toast.makeText(this, "That instrument is unavailable.", Toast.LENGTH_SHORT).show() }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun configureWindowSafely() {
        runCatching {
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    controller.hide(WindowInsets.Type.statusBars())
                    controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
        }
    }

    private fun registerPowerReceiverSafely() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        val sticky = runCatching {
            val registered = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(powerReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(powerReceiver, filter)
            }
            powerReceiverRegistered = true
            registered
        }.getOrElse {
            powerReceiverRegistered = false
            runCatching {
                @Suppress("DEPRECATION")
                registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            }.getOrNull()
        }
        sticky?.let {
            latestBatteryIntent = it
            refreshBatteryUi(it)
        }
    }

    private fun refreshBatteryUi(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val currentNow = runCatching {
            val manager = getSystemService(BatteryManager::class.java) ?: return@runCatching null
            manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        }.getOrNull()
        coreDial.refreshBattery(level, scale, temp, voltage, status, currentNow)
        headerBattery.text = "${((level.toFloat() / scale.coerceAtLeast(1)) * 100f).toInt().coerceIn(0,100)}% · ${if (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL) "POWER" else "STANDBY"}"
        statusStrip.text = coreDial.getStatusLine()
        refreshHeader()
    }

    private fun refreshHeader() {
        headerDate.text = dateFormat.format(Date()).uppercase(Locale.getDefault())
    }

    private fun sectionTitle(title: String, subtitle: String): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(TextView(this).apply {
            text = title
            setTextColor(VictorianPalette.ivory)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        wrap.addView(TextView(this).apply {
            text = subtitle
            setTextColor(VictorianPalette.silver)
            textSize = 11f
        })
        return wrap
    }

    private fun infoCapsule(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(VictorianPalette.silver)
        textSize = 11f
        setPadding(dpInt(12f), dpInt(8f), dpInt(12f), dpInt(8f))
        background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1f, radiusDp = 999f)
    }

    private fun textButton(label: String, action: () -> Unit): View = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(VictorianPalette.ivory)
        textSize = 11f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dpInt(12f), dpInt(8f), dpInt(12f), dpInt(8f))
        background = roundedPanel(VictorianPalette.panelElevated, strokeColor = VictorianPalette.softLine, strokeWidthDp = 1f, radiusDp = 999f)
        setOnClickListener { action() }
    }

    private fun roundedPanel(fillColor: Int, strokeColor: Int, strokeWidthDp: Float, radiusDp: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fillColor)
            cornerRadius = dp(radiusDp)
            setStroke(dpInt(strokeWidthDp), strokeColor)
        }
    }

    private fun ringDrawable(): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(VictorianPalette.enamel)
            setStroke(dpInt(1.4f), VictorianPalette.softLine)
        }
    }

    private fun showKeyboard(view: View) {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard(view: View) {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun space(size: Int, horizontal: Boolean = false): View = View(this).apply {
        layoutParams = if (horizontal) {
            LinearLayout.LayoutParams(size, 1)
        } else {
            LinearLayout.LayoutParams(1, size)
        }
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
    private fun dpInt(value: Float): Int = dp(value).toInt()
}
