package com.lee.victorianos.shell

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

class VictorianBackdropView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(value: Float) = value * density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawColor(VictorianPalette.enamel)

        // Soft upper glow.
        fillPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF0C1016.toInt(), VictorianPalette.enamel, VictorianPalette.enamel),
            floatArrayOf(0f, 0.38f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, fillPaint)

        // Radial HUD aura.
        fillPaint.shader = RadialGradient(
            w / 2f, h * 0.34f, w * 0.5f,
            intArrayOf(0x2417B9C8, 0x1017B9C8, 0x0017B9C8),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, fillPaint)
        fillPaint.shader = null

        linePaint.color = VictorianPalette.line
        canvas.drawLine(dp(24f), dp(66f), w - dp(24f), dp(66f), linePaint)
        canvas.drawLine(dp(24f), h - dp(82f), w - dp(24f), h - dp(82f), linePaint)

        // Brass corner marks.
        linePaint.color = VictorianPalette.brass
        val margin = dp(18f)
        val len = dp(12f)
        // top left
        canvas.drawLine(margin, dp(94f), margin + len, dp(94f), linePaint)
        canvas.drawLine(margin, dp(94f), margin, dp(94f) + len, linePaint)
        // top right
        canvas.drawLine(w - margin, dp(94f), w - margin - len, dp(94f), linePaint)
        canvas.drawLine(w - margin, dp(94f), w - margin, dp(94f) + len, linePaint)

        // Subtle framing plate.
        linePaint.color = VictorianPalette.softLine
        canvas.drawRoundRect(RectF(dp(14f), dp(14f), w - dp(14f), h - dp(14f)), dp(22f), dp(22f), linePaint)
    }
}
