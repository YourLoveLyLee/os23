package com.lee.victorianos.shell

import android.graphics.Color

object VictorianPalette {
    val enamel: Int = Color.parseColor("#090B0F")
    val panel: Int = Color.parseColor("#10141A")
    val panelElevated: Int = Color.parseColor("#141A22")
    val line: Int = Color.parseColor("#26303A")
    val softLine: Int = Color.parseColor("#31404C")
    val ivory: Int = Color.parseColor("#E9E1D3")
    val silver: Int = Color.parseColor("#A6B0BA")
    val muted: Int = Color.parseColor("#68717A")
    val brass: Int = Color.parseColor("#B5904E")
    val amber: Int = Color.parseColor("#E0A24A")
    val cyan: Int = Color.parseColor("#6EC9D4")
    val cyanSoft: Int = Color.parseColor("#23454B")
    val shadow: Int = Color.parseColor("#BF000000")
}
